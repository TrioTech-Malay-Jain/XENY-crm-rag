# Flask Structure (Legacy)

This folder contains the original Flask-based implementation of the ttRag system.

## Files
- `run_flask.py` - Original Flask application with Google Sheets integration
- `requirements_flask.txt` - Flask-specific requirements

## Features
- Flask web framework
- Google Sheets integration for chat history logging
- CORS support
- Session management
- RAG pipeline with Gemini LLM

## Note
This implementation is kept for reference purposes. The main application now uses FastAPI (see main.py in the root directory).

## To run (if needed):
1. Install Flask requirements: `pip install -r requirements_flask.txt`
2. Set up Google Sheets credentials (credentials.json)
3. Run: `python run_flask.py`

The Flask app runs on port 5000 by default.
