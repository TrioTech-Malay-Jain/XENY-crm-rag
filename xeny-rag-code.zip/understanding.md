# CCD-AI System Understanding Guide

## 📋 Complete Description

**CCD-AI** is a production-ready **Multi-Organizational Retrieval Augmented Generation (RAG) system** that provides secure, isolated document processing and intelligent querying capabilities for multiple companies. The system enables organizations to upload documents, automatically build vector databases, and interact with their data through natural language queries while maintaining complete data isolation between different companies.

### Key Features
- **Multi-organization isolation**: Each company has its own isolated files and vector database collections
- **Automatic vector database building**: Vector DB is automatically built when files are uploaded
- **Comprehensive file management**: Upload, list, delete files with metadata tracking
- **Build status monitoring**: Real-time status checking of vector database building process
- **Advanced querying**: Both company-wide and file-specific querying capabilities
- **Chat interface**: Conversational AI with chat history support
- **File-specific chat**: Direct chat with individual documents without needing company_id
- **Scalable architecture**: Easily add new companies and files
- **Modern tech stack**: Built with FastAPI, LangChain, ChromaDB, and Google Gemini

---

## 📁 Files Information & Architecture

### Directory Structure
```
CCD-AI/
├── main_multi_org.py         # Main FastAPI application entry point
├── config.py                 # Centralized configuration settings
├── requirements.txt          # Python dependencies
├── Dockerfile               # Container configuration
├── understanding.md         # This documentation file
├── README.md                # Project documentation
├── LICENSE                  # MIT License
├── report.md                # Project report
├── 
├── api/                     # API layer - REST endpoints
│   ├── __init__.py          # Router registration
│   ├── files.py             # File management endpoints
│   ├── query.py             # Query and chat endpoints
│   └── company.py           # Company management (currently disabled)
│
├── services/                # Business logic layer
│   ├── __init__.py
│   ├── file_service.py      # File operations and document loading
│   └── embedding_service.py # Vector embeddings and RAG chains
│
├── db/                      # Data access layer
│   ├── __init__.py
│   └── chroma_manager.py    # ChromaDB operations and management
│
├── models/                  # Data models and schemas
│   ├── __init__.py
│   └── schemas.py           # Pydantic models for API requests/responses
│
├── knowledge_base/          # Company data storage
│   ├── company1/            # Example company directory
│   │   ├── metadata.json    # File metadata
│   │   └── {file_id}.txt    # Actual files (named by UUID)
│   └── company2/            # Another company directory
│
├── chroma_db/               # Vector database storage
│   ├── chroma.sqlite3       # ChromaDB SQLite database
│   └── {collection_id}/     # Individual collection data
│       ├── data_level0.bin
│       ├── header.bin
│       ├── length.bin
│       └── link_lists.bin
│
├── static/                  # Static web assets
│   ├── logo.png
│   ├── favicon.ico
│   └── Advanced-RAG.png
│
├── templates/               # HTML templates
│   ├── index.html           # Main interface
│   └── admin.html           # Admin panel
│
├── archive/                 # Legacy/deprecated files
│   ├── build_db.py          # Old database builder
│   ├── run_fastapi.py       # Legacy FastAPI runner
│   └── flask_structure/     # Old Flask implementation
│
└── utility scripts/         # Helper scripts
    ├── import_existing_files.py    # Import legacy files
    ├── create_test_files.py        # Generate test data
    ├── test_automatic_build.py     # Test automation
    ├── test_file_only_chat.py      # File-specific chat testing
    ├── test_file_specific_query.py # File query testing
    └── copy_utils.py               # File utilities
```

### File Types & Purposes

#### Core Application Files
- **main_multi_org.py**: Main application entry point with FastAPI setup, CORS, static file mounting, and health checks
- **config.py**: Configuration management including API keys, paths, file settings, and environment variables
- **requirements.txt**: Python package dependencies

#### API Layer (`api/`)
- **files.py**: File upload, listing, deletion, build status, and file path management endpoints
- **query.py**: Document querying, chat functionality, and session management endpoints
- **company.py**: Company management endpoints (currently commented out/disabled)

#### Business Logic (`services/`)
- **file_service.py**: File operations, document loading, metadata management, and company isolation
- **embedding_service.py**: Vector embeddings, RAG chain creation, document processing, and query handling

#### Data Layer (`db/`)
- **chroma_manager.py**: ChromaDB operations, collection management, and vector store operations

#### Data Models (`models/`)
- **schemas.py**: Pydantic models for API requests, responses, and data validation

---

## 🏗️ System Architecture

### Layered Architecture Pattern
```
┌─────────────────────────────────────────────────┐
│                Frontend Layer                    │
│            (HTML Templates + Static)            │
└─────────────────────────────────────────────────┘
                           │
┌─────────────────────────────────────────────────┐
│                 API Layer                       │
│     (FastAPI Routes + Request/Response)         │
│  files.py │ query.py │ company.py (disabled)    │
└─────────────────────────────────────────────────┘
                           │
┌─────────────────────────────────────────────────┐
│              Business Logic Layer               │
│         (Services + Processing Logic)           │
│    file_service.py │ embedding_service.py       │
└─────────────────────────────────────────────────┘
                           │
┌─────────────────────────────────────────────────┐
│               Data Access Layer                 │
│           (Database + Vector Store)             │
│         chroma_manager.py │ File System         │
└─────────────────────────────────────────────────┘
```

### Multi-Tenant Isolation Architecture
```
Company A                    Company B                    Company C
    │                           │                           │
    ├── Files                   ├── Files                   ├── Files
    │   ├── doc1.txt            │   ├── report.pdf          │   ├── data.json
    │   └── data.json           │   └── policy.txt          │   └── manual.docx
    │                           │                           │
    ├── Vector Collection       ├── Vector Collection       ├── Vector Collection
    │   └── company_a           │   └── company_b           │   └── company_c
    │                           │                           │
    └── RAG Chain               └── RAG Chain               └── RAG Chain
        └── Isolated Queries        └── Isolated Queries        └── Isolated Queries
```

---

## 🔄 Code Flow

### 1. Application Startup Flow
```
main_multi_org.py startup
    │
    ├── Load environment variables (config.py)
    ├── Create necessary directories
    ├── Check API keys availability
    ├── List existing companies
    ├── Initialize FastAPI app with CORS
    ├── Mount static files and templates
    └── Include API routers
```

### 2. File Upload Flow
```
POST /api/v1/files/upload
    │
    ├── files.py → upload_file()
    │   │
    │   ├── Validate file extension
    │   ├── Generate unique file_id
    │   ├── Save to company directory
    │   ├── Create metadata
    │   └── Trigger background tasks
    │
    ├── Background Task 1: Process company documents
    │   └── embedding_service.process_company_documents()
    │       ├── Load all company documents
    │       ├── Split into chunks
    │       ├── Create/update vector store
    │       └── Initialize RAG chain
    │
    ├── Background Task 2: Create file-specific collection
    │   └── embedding_service.create_file_specific_collection()
    │
    └── Background Task 3: Add document to company
        └── embedding_service.add_document_to_company()
```

### 3. Query Processing Flow
```
POST /api/v1/query
    │
    ├── query.py → query_documents()
    │   │
    │   ├── Validate request (company_id, query)
    │   ├── Generate session_id if needed
    │   └── Call embedding_service.query_company()
    │
    ├── embedding_service.query_company()
    │   │
    │   ├── Check if RAG chain exists
    │   ├── Create RAG chain if needed
    │   ├── Convert chat history to LangChain format
    │   ├── Invoke RAG chain with query
    │   ├── Extract sources from context
    │   └── Return formatted response
    │
    └── Return QueryResponse with answer and metadata
```

### 4. File-Specific Chat Flow
```
POST /api/v1/query/file-chat
    │
    ├── query.py → chat_with_file()
    │   │
    │   ├── Find company_id from file_id
    │   ├── Validate file existence
    │   └── Call embedding_service.query_specific_file()
    │
    ├── embedding_service.query_specific_file()
    │   │
    │   ├── Get file-specific vector store
    │   ├── Check if collection has documents
    │   ├── Create collection if empty
    │   ├── Create single-file RAG chain
    │   ├── Process query with file context
    │   └── Return file-specific response
    │
    └── Return response with file information
```

### 5. Vector Database Management Flow
```
ChromaDB Operations
    │
    ├── Collection Creation
    │   ├── Sanitize company name
    │   ├── Generate collection name
    │   ├── Create embeddings
    │   └── Store documents with metadata
    │
    ├── Document Retrieval
    │   ├── Get company vectorstore
    │   ├── Create retriever with search parameters
    │   ├── Retrieve relevant documents
    │   └── Return ranked results
    │
    └── API Key Rotation
        ├── Rotate Google API keys on failure
        ├── Reset embedding functions
        └── Retry operations
```

---

## 🔗 APIs Called & Files Relationship

### API Endpoints to File Mapping

#### File Management APIs (`api/files.py`)
- **POST /api/v1/files/upload**
  - Files Used: `file_service.py`, `embedding_service.py`, `chroma_manager.py`
  - Triggers: Document processing, vector store creation, metadata storage

- **GET /api/v1/files/list**
  - Files Used: `file_service.py`
  - Operation: List company files from metadata

- **GET /api/v1/files/{file_id}**
  - Files Used: `file_service.py`
  - Operation: Get specific file information

- **DELETE /api/v1/files/{file_id}**
  - Files Used: `file_service.py`, `chroma_manager.py`
  - Operation: Delete file and vector store entries

- **GET /api/v1/files/build-status/{company_id}**
  - Files Used: `embedding_service.py`
  - Operation: Check vector database build status

#### Query APIs (`api/query.py`)
- **POST /api/v1/query**
  - Files Used: `embedding_service.py`, `chroma_manager.py`, `file_service.py`
  - Operation: Query company documents with RAG

- **POST /api/v1/chat**
  - Files Used: `embedding_service.py`, chat session management
  - Operation: Conversational interface with chat history

- **POST /api/v1/query/file-chat**
  - Files Used: `file_service.py`, `embedding_service.py`, `chroma_manager.py`
  - Operation: Chat with specific file

- **GET /api/v1/query/file-info/{file_id}**
  - Files Used: `file_service.py`
  - Operation: Get file info without company_id

### Service Layer Dependencies

#### `file_service.py` Dependencies
- **External Libraries**: `fastapi`, `langchain_community.document_loaders`, `pathlib`, `json`
- **Internal Dependencies**: `config.py`, `models/schemas.py`
- **Operations**: File I/O, metadata management, document loading

#### `embedding_service.py` Dependencies
- **External Libraries**: `langchain`, `langchain_google_genai`, `langchain_chroma`
- **Internal Dependencies**: `config.py`, `db/chroma_manager.py`, `services/file_service.py`, `models/schemas.py`
- **Operations**: Vector embeddings, RAG chain creation, query processing

#### `chroma_manager.py` Dependencies
- **External Libraries**: `langchain_chroma`, `langchain_google_genai`
- **Internal Dependencies**: `config.py`
- **Operations**: Vector database management, collection operations

---

## 🛠️ Tech Stack & Their Functions

### Core Framework
- **FastAPI (0.104.1)**
  - Purpose: Web framework for building APIs
  - Functions: HTTP routing, request/response handling, automatic API documentation, dependency injection
  - Why chosen: High performance, automatic OpenAPI docs, type hints support

- **Uvicorn (0.24.0)**
  - Purpose: ASGI server for running FastAPI
  - Functions: Asynchronous request handling, hot reloading during development
  - Why chosen: High-performance, supports async operations

### AI & Machine Learning
- **LangChain (0.1.0)**
  - Purpose: Framework for developing LLM-powered applications
  - Functions: Document loading, text splitting, chain creation, retrieval management
  - Components Used:
    - `RecursiveCharacterTextSplitter`: Smart text chunking
    - `create_history_aware_retriever`: Context-aware retrieval
    - `create_retrieval_chain`: RAG pipeline creation

- **Google Generative AI (1.0.1)**
  - Purpose: Google's Gemini LLM integration
  - Functions: Text generation, embeddings creation, chat completion
  - Models Used:
    - `gemini-1.5-flash`: Main conversation model
    - `models/embedding-001`: Text embeddings

- **LangChain Google GenAI (1.0.1)**
  - Purpose: LangChain integration with Google AI
  - Functions: Seamless Google AI integration with LangChain chains

### Vector Database
- **ChromaDB (0.4.18)**
  - Purpose: Vector database for similarity search
  - Functions: Vector storage, similarity search, metadata filtering, collection management
  - Why chosen: Easy setup, good Python integration, supports metadata

- **LangChain Chroma (0.1.0)**
  - Purpose: LangChain integration with ChromaDB
  - Functions: Vector store operations, retrieval interface, document management

### Document Processing
- **PyPDF (4.0.0)**
  - Purpose: PDF document processing
  - Functions: Extract text from PDF files, handle metadata
  - Why chosen: Pure Python, reliable PDF parsing

- **python-docx (1.1.0) & docx2txt (0.8)**
  - Purpose: Microsoft Word document processing
  - Functions: Extract text from .docx files
  - Why chosen: Reliable DOCX parsing, maintains formatting

- **Unstructured (0.11.0)**
  - Purpose: Advanced document processing
  - Functions: Handle complex document formats, extract structured data
  - Why chosen: Handles various document types, good text extraction

### Web & API
- **Pydantic (2.5.0)**
  - Purpose: Data validation and serialization
  - Functions: Request/response validation, type checking, automatic documentation
  - Why chosen: Type safety, automatic validation, FastAPI integration

- **python-multipart (0.0.6)**
  - Purpose: File upload handling
  - Functions: Parse multipart form data for file uploads
  - Why chosen: Required for FastAPI file uploads

- **Jinja2 (3.1.2)**
  - Purpose: Template engine for HTML rendering
  - Functions: Dynamic HTML generation, template inheritance
  - Why chosen: FastAPI's default template engine

- **aiofiles (23.2.1)**
  - Purpose: Async file operations
  - Functions: Non-blocking file I/O operations
  - Why chosen: Async support for better performance

### Configuration & Environment
- **python-dotenv (1.0.0)**
  - Purpose: Environment variable management
  - Functions: Load configuration from .env files
  - Why chosen: Secure configuration management, environment separation

### API Key Management & Rate Limiting
- **Multiple Google API Keys Support**
  - Purpose: Rate limiting and failover
  - Functions: Automatic key rotation on rate limits, load distribution
  - Implementation: Round-robin key rotation in `embedding_service.py` and `chroma_manager.py`

### Security Features
- **CORS Middleware**
  - Purpose: Cross-origin resource sharing
  - Functions: Control API access from web browsers
  - Configuration: Configurable origins for production security

- **File Type Validation**
  - Purpose: Security and processing optimization
  - Functions: Restrict file uploads to supported formats
  - Supported: `.txt`, `.json`, `.pdf`, `.docx`

### Data Isolation Architecture
- **Multi-tenant Design**
  - Purpose: Company data isolation
  - Functions: Separate file storage, vector collections, and RAG chains per company
  - Implementation: Directory-based file isolation + collection-based vector isolation

### Monitoring & Debugging
- **Build Status Tracking**
  - Purpose: Monitor vector database building progress
  - Functions: Real-time status updates, progress tracking, error reporting
  - Implementation: In-memory status storage with timestamps

- **Health Check Endpoints**
  - Purpose: System monitoring and debugging
  - Functions: Check API keys, database status, company counts
  - Endpoints: `/health`, `/api/v1/health`

### Performance Optimizations
- **Background Task Processing**
  - Purpose: Non-blocking operations
  - Functions: File processing, vector store building, document indexing
  - Implementation: FastAPI background tasks

- **Lazy Loading**
  - Purpose: Resource optimization
  - Functions: RAG chains created only when needed, API key rotation on failure
  - Implementation: On-demand chain creation in `embedding_service.py`

- **Caching Strategy**
  - Purpose: Performance optimization
  - Functions: In-memory RAG chain storage, session management
  - Implementation: Dictionary-based caching with company-level isolation

---

## 🚫 Adding to .gitignore

The `understanding.md` file should be added to `.gitignore` to keep it private and prevent it from being committed to the repository.

---

*This document provides a comprehensive understanding of the CCD-AI Multi-Organizational RAG system architecture, codebase, and implementation details.*
