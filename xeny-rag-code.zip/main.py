"""
ARCHIVED: This file is the legacy single-org FastAPI app.
It is not used in the current multi-org architecture.
All code below is commented out for reference/migration only.
"""
# from fastapi import FastAPI, UploadFile, File, HTTPException, BackgroundTasks, Request
# from fastapi.middleware.cors import CORSMiddleware
# from fastapi.responses import JSONResponse, HTMLResponse
# from fastapi.staticfiles import StaticFiles
# from fastapi.templating import Jinja2Templates
# from pydantic import BaseModel
# import os
# import shutil
# import json
# import asyncio
# from pathlib import Path
# from typing import List, Optional
# import uuid
# from datetime import datetime

# # Import existing RAG components
# from dotenv import load_dotenv
# from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
# from langchain_chroma import Chroma
# from langchain.chains import create_history_aware_retriever, create_retrieval_chain
# from langchain.chains.combine_documents import create_stuff_documents_chain
# from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
# from langchain_core.messages import HumanMessage, AIMessage
# from langchain_community.document_loaders import (
#     DirectoryLoader, 
#     TextLoader, 
#     PyPDFLoader, 
#     Docx2txtLoader,
#     JSONLoader
# )
# from langchain.text_splitter import RecursiveCharacterTextSplitter

# # Load environment variables
# load_dotenv()

# app = FastAPI(title="ttRag Knowledge Base System", version="1.0.0")

# # CORS configuration
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# # Mount static files and templates
# app.mount("/static", StaticFiles(directory="static"), name="static")
# templates = Jinja2Templates(directory="templates")

# # Configuration
# KNOWLEDGE_BASE_DIR = "./knowledge_base"
# CHROMA_DB_PATH = "./chroma_db"
# ALLOWED_EXTENSIONS = {".txt", ".json", ".pdf", ".docx"}

# # Global variables
# rag_chain = None
# api_keys = []
# current_key_index = 0
# build_status = {"status": "idle", "message": "", "timestamp": None}
# chat_sessions = {}

# # Pydantic models
# class QueryRequest(BaseModel):
#     query: str
#     session_id: Optional[str] = None
#     history: Optional[List[dict]] = []

# class QueryResponse(BaseModel):
#     response: str
#     session_id: str
#     timestamp: str

# class FileInfo(BaseModel):
#     filename: str
#     size: int
#     created_at: str
#     extension: str

# class BuildStatus(BaseModel):
#     status: str
#     message: str
#     timestamp: Optional[str]

# class ChatMessage(BaseModel):
#     message: str
#     sender: str
#     timestamp: str

# # Initialize directories
# def init_directories():
#     """Create necessary directories if they don't exist"""
#     os.makedirs(KNOWLEDGE_BASE_DIR, exist_ok=True)
#     os.makedirs(CHROMA_DB_PATH, exist_ok=True)
#     os.makedirs("static", exist_ok=True)
#     os.makedirs("templates", exist_ok=True)

# # Load API keys
# def load_api_keys():
#     global api_keys
#     i = 1
#     while True:
#         key = os.getenv(f"GOOGLE_API_KEY_{i}")
#         if key:
#             api_keys.append(key)
#             i += 1
#         else:
#             break
#     if not api_keys:
#         raise Exception("No Google API keys found in environment variables")

# # Initialize RAG pipeline
# async def initialize_rag_pipeline():
#     global rag_chain, current_key_index
    
#     if not api_keys:
#         raise Exception("No API keys available")
    
#     try:
#         api_key = api_keys[current_key_index]
#         llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash", google_api_key=api_key)
#         embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001", google_api_key=api_key)
        
#         if not os.path.exists(CHROMA_DB_PATH) or not os.listdir(CHROMA_DB_PATH):
#             return False
            
#         vectorstore = Chroma(persist_directory=CHROMA_DB_PATH, embedding_function=embeddings)
#         retriever = vectorstore.as_retriever()

#         contextualize_q_prompt = ChatPromptTemplate.from_messages([
#             ("system", "Given a chat history and the latest user question which might reference context in the chat history, formulate a standalone question which can be understood without the chat history."),
#             MessagesPlaceholder("chat_history"),
#             ("human", "{input}")
#         ])
#         history_aware_retriever = create_history_aware_retriever(llm, retriever, contextualize_q_prompt)

#         # Updated system prompt
#         system_prompt = """You are an advanced AI assistant with expertise in understanding and explaining complex information.
# Your role is to answer user questions comprehensively using the provided knowledge base context.

# Guidelines:
# 1. Always ground your answers in the provided context, but expand with reasoning, clarification, and related insights.
# 2. Provide clear, structured, and well-organized responses (use sections, bullet points, or lists where helpful).
# 3. Be detailed — explain concepts fully instead of giving short or vague replies.
# 4. Highlight key insights, important details, and actionable information.
# 5. If something is unclear in the context, infer the most likely explanation and explicitly state your assumptions.
# 6. If the information truly does not exist in the knowledge base, say: 
#    "The available knowledge base does not provide a direct answer to this question," 
#    and suggest possible directions or related knowledge.

# Context:
# {context}"""

#         qa_prompt = ChatPromptTemplate.from_messages([
#             ("system", system_prompt),
#             MessagesPlaceholder("chat_history"),
#             ("human", "{input}")
#         ])
        
#         question_answer_chain = create_stuff_documents_chain(llm, qa_prompt)
#         rag_chain = create_retrieval_chain(history_aware_retriever, question_answer_chain)
#         return True
#     except Exception as e:
#         print(f"Error initializing RAG pipeline: {e}")
#         # Try next API key
#         current_key_index = (current_key_index + 1) % len(api_keys)
#         return False

# def load_documents_from_directory(directory_path):
#     """
#     Load documents from directory supporting multiple file formats:
#     - .txt files
#     - .pdf files  
#     - .docx files
#     - .json files
#     """
#     all_documents = []
#     directory = Path(directory_path)
    
#     # Define supported file patterns
#     supported_files = {
#         '*.txt': TextLoader,
#         '*.pdf': PyPDFLoader,
#         '*.docx': Docx2txtLoader,
#         '*.json': None  # Handle JSON separately
#     }
    
#     for pattern, loader_class in supported_files.items():
#         files = list(directory.glob(pattern))
        
#         if pattern == '*.json':
#             # Handle JSON files separately
#             for file_path in files:
#                 try:
#                     with open(file_path, 'r', encoding='utf-8') as f:
#                         json_data = json.load(f)
                    
#                     # Convert JSON to text format
#                     if isinstance(json_data, dict):
#                         text_content = json.dumps(json_data, indent=2, ensure_ascii=False)
#                     elif isinstance(json_data, list):
#                         text_content = '\n'.join([
#                             json.dumps(item, indent=2, ensure_ascii=False) 
#                             if isinstance(item, (dict, list)) 
#                             else str(item) 
#                             for item in json_data
#                         ])
#                     else:
#                         text_content = str(json_data)
                    
#                     # Create document with metadata
#                     from langchain.schema import Document
#                     doc = Document(
#                         page_content=text_content,
#                         metadata={
#                             'source': str(file_path),
#                             'file_type': 'json',
#                             'filename': file_path.name
#                         }
#                     )
#                     all_documents.append(doc)
                    
#                 except Exception as e:
#                     print(f"ERROR loading JSON file {file_path}: {e}")
#                     continue
#         else:
#             # Handle other file types with their respective loaders
#             for file_path in files:
#                 try:
#                     if loader_class == TextLoader:
#                         loader = loader_class(str(file_path), encoding='utf-8')
#                     else:
#                         loader = loader_class(str(file_path))
                    
#                     docs = loader.load()
                    
#                     # Add file type to metadata
#                     for doc in docs:
#                         doc.metadata['file_type'] = pattern.replace('*.', '')
#                         doc.metadata['filename'] = file_path.name
                    
#                     all_documents.extend(docs)
                    
#                 except Exception as e:
#                     print(f"ERROR loading file {file_path}: {e}")
#                     continue
    
#     return all_documents

# # Background task for building vector database
# async def build_vector_db_task():
#     global build_status
    
#     build_status = {"status": "building", "message": "Starting vector database build...", "timestamp": datetime.now().isoformat()}
    
#     try:
#         # Check if knowledge base has files
#         kb_files = (list(Path(KNOWLEDGE_BASE_DIR).glob("*.txt")) + 
#                    list(Path(KNOWLEDGE_BASE_DIR).glob("*.json")) +
#                    list(Path(KNOWLEDGE_BASE_DIR).glob("*.pdf")) +
#                    list(Path(KNOWLEDGE_BASE_DIR).glob("*.docx")))
#         if not kb_files:
#             build_status = {"status": "error", "message": "No knowledge base files found", "timestamp": datetime.now().isoformat()}
#             return
        
#         build_status["message"] = "Loading documents..."
        
#         # Load documents with multi-format support
#         docs = load_documents_from_directory(KNOWLEDGE_BASE_DIR)
        
#         if not docs:
#             build_status = {"status": "error", "message": "No documents could be loaded", "timestamp": datetime.now().isoformat()}
#             return
        
#         build_status["message"] = f"Loaded {len(docs)} documents, splitting into chunks..."
        
#         # Split documents
#         text_splitter = RecursiveCharacterTextSplitter(chunk_size=2000, chunk_overlap=200)
#         splits = text_splitter.split_documents(docs)
        
#         build_status["message"] = f"Split into {len(splits)} chunks, creating embeddings..."
        
#         # Create embeddings
#         api_key = api_keys[current_key_index] if api_keys else os.getenv("GOOGLE_API_KEY_1")
#         embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001", google_api_key=api_key)
        
#         # Remove existing database
#         if os.path.exists(CHROMA_DB_PATH):
#             shutil.rmtree(CHROMA_DB_PATH)
        
#         build_status["message"] = "Creating vector database..."
        
#         # Create new vector database
#         Chroma.from_documents(
#             documents=splits, 
#             embedding=embeddings, 
#             persist_directory=CHROMA_DB_PATH
#         )
        
#         build_status["message"] = "Initializing RAG pipeline..."
        
#         # Reinitialize RAG pipeline
#         success = await initialize_rag_pipeline()
#         if success:
#             build_status = {"status": "completed", "message": "Vector database built successfully!", "timestamp": datetime.now().isoformat()}
#         else:
#             build_status = {"status": "error", "message": "Failed to initialize RAG pipeline", "timestamp": datetime.now().isoformat()}
            
#     except Exception as e:
#         build_status = {"status": "error", "message": f"Build failed: {str(e)}", "timestamp": datetime.now().isoformat()}

# # Startup event
# @app.on_event("startup")
# async def startup_event():
#     init_directories()
#     load_api_keys()
#     # Try to initialize RAG pipeline if vector DB exists
#     if os.path.exists(CHROMA_DB_PATH) and os.listdir(CHROMA_DB_PATH):
#         await initialize_rag_pipeline()

# # Frontend Routes
# @app.get("/", response_class=HTMLResponse)
# async def home(request: Request):
#     """Serve the main chat interface"""
#     return templates.TemplateResponse("index.html", {"request": request})

# @app.get("/admin", response_class=HTMLResponse)
# async def admin_panel(request: Request):
#     """Serve the admin panel for knowledge base management"""
#     return templates.TemplateResponse("admin.html", {"request": request})

# # API Endpoints

# @app.post("/api/upload")
# async def upload_file(file: UploadFile = File(...)):
#     """Upload a knowledge base file (.txt, .json, .pdf, .docx)"""
    
#     # Validate file extension
#     file_extension = Path(file.filename).suffix.lower()
#     if file_extension not in ALLOWED_EXTENSIONS:
#         raise HTTPException(
#             status_code=400, 
#             detail=f"File type {file_extension} not allowed. Only {ALLOWED_EXTENSIONS} are supported."
#         )
    
#     # Validate file content for JSON files
#     if file_extension == ".json":
#         try:
#             content = await file.read()
#             json.loads(content.decode('utf-8'))
#             await file.seek(0)  # Reset file pointer
#         except json.JSONDecodeError:
#             raise HTTPException(status_code=400, detail="Invalid JSON format")
    
#     # Save file
#     file_path = os.path.join(KNOWLEDGE_BASE_DIR, file.filename)
#     try:
#         with open(file_path, "wb") as buffer:
#             shutil.copyfileobj(file.file, buffer)
        
#         file_size = os.path.getsize(file_path)
#         return {
#             "message": f"File '{file.filename}' uploaded successfully",
#             "filename": file.filename,
#             "size": file_size,
#             "type": file_extension
#         }
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Failed to save file: {str(e)}")

# @app.get("/api/files", response_model=List[FileInfo])
# async def list_files():
#     """List all files in the knowledge base directory"""
    
#     files = []
#     try:
#         for file_path in Path(KNOWLEDGE_BASE_DIR).iterdir():
#             if file_path.is_file() and file_path.suffix.lower() in ALLOWED_EXTENSIONS:
#                 stat = file_path.stat()
#                 files.append(FileInfo(
#                     filename=file_path.name,
#                     size=stat.st_size,
#                     created_at=datetime.fromtimestamp(stat.st_ctime).isoformat(),
#                     extension=file_path.suffix.lower()
#                 ))
#         return files
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Failed to list files: {str(e)}")

# @app.delete("/api/files/{filename}")
# async def delete_file(filename: str):
#     """Delete a file from the knowledge base directory"""
    
#     file_path = os.path.join(KNOWLEDGE_BASE_DIR, filename)
    
#     if not os.path.exists(file_path):
#         raise HTTPException(status_code=404, detail=f"File '{filename}' not found")
    
#     try:
#         os.remove(file_path)
#         return {"message": f"File '{filename}' deleted successfully"}
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Failed to delete file: {str(e)}")

# @app.post("/api/build_db", response_model=BuildStatus)
# async def build_database(background_tasks: BackgroundTasks):
#     """Build/rebuild the vector database from knowledge base files"""
    
#     if build_status["status"] == "building":
#         return BuildStatus(**build_status)
    
#     background_tasks.add_task(build_vector_db_task)
#     return BuildStatus(
#         status="building", 
#         message="Vector database build started...", 
#         timestamp=datetime.now().isoformat()
#     )

# @app.get("/api/build_status", response_model=BuildStatus)
# async def get_build_status():
#     """Get the current status of the vector database build"""
#     return BuildStatus(**build_status)

# @app.post("/api/chat")
# async def chat_endpoint(request: QueryRequest):
#     """Chat endpoint for the frontend"""
    
#     if not rag_chain:
#         raise HTTPException(
#             status_code=503, 
#             detail="RAG system not initialized. Please build the vector database first."
#         )
    
#     session_id = request.session_id or str(uuid.uuid4())
    
#     # Get or create chat session
#     if session_id not in chat_sessions:
#         chat_sessions[session_id] = []
    
#     # Convert history to LangChain format
#     chat_history_for_chain = []
#     for msg in request.history:
#         content = msg.get('message', '')
#         if msg.get('sender') == 'user':
#             chat_history_for_chain.append(HumanMessage(content=content))
#         else:
#             chat_history_for_chain.append(AIMessage(content=content))
    
#     try:
#         response = rag_chain.invoke({
#             "input": request.query, 
#             "chat_history": chat_history_for_chain
#         })
        
#         # Store in session
#         chat_sessions[session_id].append({
#             "message": request.query,
#             "sender": "user",
#             "timestamp": datetime.now().isoformat()
#         })
        
#         bot_response = response.get("answer", "I couldn't find an answer to that.")
#         chat_sessions[session_id].append({
#             "message": bot_response,
#             "sender": "bot",
#             "timestamp": datetime.now().isoformat()
#         })
        
#         return {
#             "response": bot_response,
#             "session_id": session_id,
#             "timestamp": datetime.now().isoformat()
#         }
        
#     except Exception as e:
#         # Try switching API keys if rate limited
#         global current_key_index
#         if "quota" in str(e).lower() or "rate" in str(e).lower():
#             current_key_index = (current_key_index + 1) % len(api_keys)
#             await initialize_rag_pipeline()
#             raise HTTPException(status_code=429, detail="Rate limit exceeded. Please try again.")
        
#         raise HTTPException(status_code=500, detail=f"Query failed: {str(e)}")

# @app.post("/api/query", response_model=QueryResponse)
# async def query_rag(request: QueryRequest):
#     """Query the RAG system (API endpoint)"""
    
#     if not rag_chain:
#         raise HTTPException(
#             status_code=503, 
#             detail="RAG system not initialized. Please build the vector database first."
#         )
    
#     session_id = request.session_id or str(uuid.uuid4())
    
#     # Convert history to LangChain format
#     chat_history_for_chain = []
#     for msg in request.history:
#         content = msg.get('message', '')
#         if msg.get('sender') == 'user':
#             chat_history_for_chain.append(HumanMessage(content=content))
#         else:
#             chat_history_for_chain.append(AIMessage(content=content))
    
#     try:
#         response = rag_chain.invoke({
#             "input": request.query, 
#             "chat_history": chat_history_for_chain
#         })
        
#         return QueryResponse(
#             response=response.get("answer", "I couldn't find an answer to that."),
#             session_id=session_id,
#             timestamp=datetime.now().isoformat()
#         )
        
#     except Exception as e:
#         # Try switching API keys if rate limited
#         global current_key_index
#         if "quota" in str(e).lower() or "rate" in str(e).lower():
#             current_key_index = (current_key_index + 1) % len(api_keys)
#             await initialize_rag_pipeline()
#             raise HTTPException(status_code=429, detail="Rate limit exceeded. Please try again.")
        
#         raise HTTPException(status_code=500, detail=f"Query failed: {str(e)}")

# @app.get("/api/chat_history/{session_id}")
# async def get_chat_history(session_id: str):
#     """Get chat history for a session"""
#     return chat_sessions.get(session_id, [])

# @app.delete("/api/chat_history/{session_id}")
# async def clear_chat_history(session_id: str):
#     """Clear chat history for a session"""
#     if session_id in chat_sessions:
#         chat_sessions[session_id] = []
#     return {"message": "Chat history cleared"}

# @app.get("/api/health")
# async def health_check():
#     """Health check endpoint"""
#     return {
#         "status": "healthy",
#         "rag_initialized": rag_chain is not None,
#         "api_keys_loaded": len(api_keys),
#         "build_status": build_status["status"],
#         "timestamp": datetime.now().isoformat()
#     }

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8000)
